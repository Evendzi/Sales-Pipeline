import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { 
  BookOpen, 
  Trash2, 
  Eye,
  Save,
  Send,
  Search
} from "lucide-react";
import { assessmentService } from "@/api/assessmentService";
import { schoolService, type School, type AvailableGrade } from "@/api/schoolService";
import { mentorService } from "@/api/mentorService";
import { sessionService, type Session } from "@/api/sessionService";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface Question {
  _id: string;
  questionText: string;
  session: {
    _id: string;
    name: string;
    displayName: string;
  };
  answerType: string;
  answerChoices: Array<{
    text: string;
    isCorrect: boolean;
    order: number;
  }>;
  correctAnswers: number[];
  difficulty: string;
  order: number;
  isActive: boolean;
}

interface SelectedQuestion extends Question {
  marks: number;
  order: number;
}

export default function CreateAssessmentPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  
  // Form state
  const [formData, setFormData] = useState({
    title: "",
    instructions: "",
    school: "",
    grade: "",
    sections: [] as string[],
    session: "",
    startDate: "",
    endDate: "",
    duration: 60,
  });

  // Question selection state
  const [availableQuestions, setAvailableQuestions] = useState<Question[]>([]);
  const [selectedQuestions, setSelectedQuestions] = useState<SelectedQuestion[]>([]);
  const [questionFilters, setQuestionFilters] = useState({
    grade: "",
    session: "",
    difficulty: "all",
  });
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredQuestions, setFilteredQuestions] = useState<Question[]>([]);
  const [duplicateQuestions, setDuplicateQuestions] = useState<any[]>([]);

  // UI state
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1); // 1: Basic Info, 2: Questions, 3: Preview
  const [, setSessions] = useState<Session[]>([]);
  
  // School and section state
  const [schools, setSchools] = useState<School[]>([]);
  const [availableGrades, setAvailableGrades] = useState<AvailableGrade[]>([]);
  const [availableSections, setAvailableSections] = useState<string[]>([]);
  const [hasServiceDetails, setHasServiceDetails] = useState(false);

  // Load schools for SuperAdmin/LeadMentor and mentor profile for mentors
  useEffect(() => {
    const loadSchools = async () => {
      if (user?.role === "superadmin" || user?.role === "leadmentor") {
        try {
          const response = await schoolService.getAll();
          if (response.success) {
            setSchools(response.data);
          }
        } catch (error) {
          console.error("Error loading schools:", error);
          toast.error("Failed to load schools");
        }
      } else if (user?.role === "mentor") {
        try {
          const response = await mentorService.getMyProfile();
          if (response.success) {
            // Convert assigned schools to the format expected by the form
            const assignedSchools: School[] = response.data.assignedSchools.map((school: any) => ({
              _id: school._id,
              name: school.name,
              address: school.address || "",
              city: school.city || "",
              state: school.state || "",
              district: school.district || "",
              pinCode: school.pinCode || "",
              schoolEmail: school.schoolEmail || "",
              schoolWebsite: school.schoolWebsite || "",
              principalName: school.principalName || "",
              principalContact: school.principalContact || "",
              principalEmail: school.principalEmail || "",
              boards: (school.boards || []) as ("CBSE" | "ICSE" | "State Board" | "IGCSE" | "IB" | "Other")[],
              branchName: school.branchName || "",
              affiliatedTo: school.affiliatedTo || undefined,
              image: school.image || undefined,
              logo: school.logo || undefined,
              stemCoordinatorName: school.stemCoordinatorName || undefined,
              stemCoordinatorContact: school.stemCoordinatorContact || undefined,
              stemCoordinatorEmail: school.stemCoordinatorEmail || undefined,
              projectStartDate: school.projectStartDate || undefined,
              projectEndDate: school.projectEndDate || undefined,
              serviceDetails: school.serviceDetails || undefined,
              students_strength: school.students_strength || 0,
              isActive: school.isActive !== undefined ? school.isActive : true,
              createdAt: school.createdAt || new Date().toISOString(),
              updatedAt: school.updatedAt || new Date().toISOString()
            }));
            setSchools(assignedSchools);
            // Don't automatically set school - let mentor choose
          }
        } catch (error) {
          console.error("Error loading mentor profile:", error);
          toast.error("Failed to load mentor profile");
        }
      }
    };

    loadSchools();
  }, [user?.role]);

  // Check for duplicate data from sessionStorage
  useEffect(() => {
    const duplicateData = sessionStorage.getItem('duplicateAssessmentData');
    if (duplicateData) {
      try {
        const data = JSON.parse(duplicateData);
        setFormData(prev => ({
          ...prev,
          title: data.title || "",
          instructions: data.instructions || "",
          school: data.school || "",
          grade: data.grade ? data.grade.toString() : "",
          sections: data.sections || [],
          session: data.session || "",
          duration: data.duration || 60,
        }));
        
        // Set selected questions if available
        if (data.questions && data.questions.length > 0) {
          setDuplicateQuestions(data.questions);
        }
        
        // Ensure question list loads for the pre-selected grade
        if (data.grade) {
          setQuestionFilters(prev => ({
            ...prev,
            grade: data.grade.toString(),
          }));
        }

        // Clear the duplication payload immediately after consuming it
        // so a fresh "Create" visit does not auto-fill unintentionally
        sessionStorage.removeItem('duplicateAssessmentData');

        toast.success("Assessment data loaded for duplication");
      } catch (error) {
        console.error("Error parsing duplicate data:", error);
        sessionStorage.removeItem('duplicateAssessmentData');
      }
    }
  }, []);

  // Load school service details when school changes
  useEffect(() => {
    const fetchSchoolServiceDetails = async (schoolId: string) => {
      try {
        const response = await schoolService.getServiceDetails(schoolId);
        if (response.success) {
          setAvailableGrades(response.data.grades);
          setHasServiceDetails(response.data.hasServiceDetails);
          
          // If we have a grade selected, set the available sections
          if (formData.grade) {
            const selectedGradeData = response.data.grades.find((gradeData: any) => 
              gradeData.grade === parseInt(formData.grade)
            );
            if (selectedGradeData) {
              setAvailableSections(selectedGradeData.sections || []);
            }
          }
        }
      } catch (error) {
        console.error("Error fetching school service details:", error);
        setAvailableGrades([]);
        setHasServiceDetails(false);
      }
    };

    if (formData.school) {
      fetchSchoolServiceDetails(formData.school);
    } else {
      setAvailableGrades([]);
      setHasServiceDetails(false);
      setAvailableSections([]);
    }
  }, [formData.school, formData.grade]);

  // Session selection not required anymore, but we still keep sessions in state if needed elsewhere
  useEffect(() => {
    const loadSessions = async () => {
      try {
        const gradeNumber = parseInt(formData.grade.replace(/\D/g, ''));
        if (isNaN(gradeNumber)) {
          setSessions([]);
          return;
        }
        const response = await sessionService.getSessionsByGrade(gradeNumber);
        setSessions(response || []);
      } catch (error) {
        setSessions([]);
      }
    };
    if (formData.grade) loadSessions();
  }, [formData.grade]);

  // Load questions when grade/difficulty filter changes
  useEffect(() => {
    const loadQuestions = async () => {
      // Fetch by grade's sessions in backend, only need grade
      if (!questionFilters.grade) return;

      try {
        // Create filter object, excluding difficulty if it's "all"
        const filters: any = { ...questionFilters };
        if (filters.difficulty === "all") {
          delete filters.difficulty;
        }
        // Do not send session; backend will derive from grade
        delete filters.session;
        const response = await assessmentService.getQuestionsForAssessment(filters);
        setAvailableQuestions(response.data || []);
      } catch (error) {
        console.error("Error loading questions:", error);
        toast.error("Failed to load questions");
      }
    };

    loadQuestions();
  }, [questionFilters]);

  // Filter questions based on search term and difficulty
  useEffect(() => {
    let filtered = availableQuestions;

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(q => 
        q.questionText.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filter by difficulty (if not already filtered by API)
    if (questionFilters.difficulty && questionFilters.difficulty !== "all") {
      filtered = filtered.filter(q => q.difficulty === questionFilters.difficulty);
    }

    setFilteredQuestions(filtered);
  }, [availableQuestions, searchTerm, questionFilters.difficulty]);

  // Handle duplicate questions when available questions are loaded
  useEffect(() => {
    if (duplicateQuestions.length > 0 && availableQuestions.length > 0) {
      const duplicateQuestionIds = duplicateQuestions.map(q => q.questionId);
      const questionsToSelect = availableQuestions.filter(q => 
        duplicateQuestionIds.includes(q._id)
      );
      
      if (questionsToSelect.length > 0) {
        const selectedQuestionsWithMarks = questionsToSelect.map(question => {
          const duplicateData = duplicateQuestions.find(dq => dq.questionId === question._id);
          return {
            ...question,
            marks: duplicateData?.marks || 1,
            order: duplicateData?.order || 1,
          };
        });
        
        setSelectedQuestions(selectedQuestionsWithMarks);
        setDuplicateQuestions([]); // Clear duplicate questions after processing
      }
    }
  }, [availableQuestions, duplicateQuestions]);

  const handleInputChange = (field: string, value: any) => {
    if (field === "school") {
      // Reset grade and sections when school changes
      setFormData(prev => ({ ...prev, [field]: value, grade: "", sections: [] }));
      setAvailableSections([]);
    } else if (field === "grade") {
      // Reset sections when grade changes and update available sections
      setFormData(prev => ({ ...prev, [field]: value, sections: [] }));
      
      if (value && hasServiceDetails) {
        // Find the selected grade in available grades and get its sections
        const selectedGradeData = availableGrades.find(gradeData => gradeData.grade === parseInt(value));
        setAvailableSections(selectedGradeData?.sections || []);
      } else {
        setAvailableSections([]);
      }
    } else {
      setFormData(prev => ({ ...prev, [field]: value }));
    }

    // Update question filters when grade changes
    if (field === "grade") {
      setQuestionFilters(prev => ({
        ...prev,
        [field]: value,
      }));
    }
  };


  const handleSectionToggle = (section: string) => {
    const newSections = formData.sections.includes(section)
      ? formData.sections.filter(s => s !== section)
      : [...formData.sections, section];

    setFormData(prev => ({ ...prev, sections: newSections }));
  };

  const handleQuestionSelect = (question: Question) => {
    const isSelected = selectedQuestions.some(q => q._id === question._id);
    
    if (isSelected) {
      setSelectedQuestions(prev => prev.filter(q => q._id !== question._id));
    } else {
      const newQuestion: SelectedQuestion = {
        ...question,
        marks: 1,
        order: selectedQuestions.length + 1,
      };
      setSelectedQuestions(prev => [...prev, newQuestion]);
    }
  };

  const handleQuestionMarksChange = (questionId: string, marks: number) => {
    setSelectedQuestions(prev =>
      prev.map(q => q._id === questionId ? { ...q, marks } : q)
    );
  };


  const removeQuestion = (questionId: string) => {
    setSelectedQuestions(prev => {
      const filtered = prev.filter(q => q._id !== questionId);
      return filtered.map((q, index) => ({ ...q, order: index + 1 }));
    });
  };

  // Convert a local datetime-local string to a UTC ISO string
  const toUtcIsoString = (localDateTime: string) => new Date(localDateTime).toISOString();

  const handleSaveDraft = async () => {
    if (!validateForm()) return;

    setLoading(true);
    try {
      // Extract numeric grade from "Grade X" format
      const gradeNumber = parseInt(formData.grade.replace(/\D/g, ''));
      
      const assessmentData = {
        ...formData,
        startDate: toUtcIsoString(formData.startDate),
        endDate: toUtcIsoString(formData.endDate),
        grade: gradeNumber, // Send numeric grade instead of string
        questions: selectedQuestions.map(q => ({
          questionId: q._id,
          order: q.order,
          marks: q.marks,
        })),
      };

      await assessmentService.createAssessment(assessmentData);
      // Clear any duplicate data from sessionStorage
      sessionStorage.removeItem('duplicateAssessmentData');
      toast.success("Assessment saved as draft");
      navigate("/mentor/assessments");
    } catch (error) {
      console.error("Error saving assessment:", error);
      toast.error("Failed to save assessment");
    } finally {
      setLoading(false);
    }
  };

  const handlePublish = async () => {
    if (!validateForm()) return;

    const notificationMessage = prompt("Enter notification message for students (optional):");
    
    setLoading(true);
    try {
      // Extract numeric grade from "Grade X" format
      const gradeNumber = parseInt(formData.grade.replace(/\D/g, ''));
      
      const assessmentData = {
        ...formData,
        startDate: toUtcIsoString(formData.startDate),
        endDate: toUtcIsoString(formData.endDate),
        grade: gradeNumber, // Send numeric grade instead of string
        questions: selectedQuestions.map(q => ({
          questionId: q._id,
          order: q.order,
          marks: q.marks,
        })),
      };

      const response = await assessmentService.createAssessment(assessmentData);
      
      if (notificationMessage) {
        await assessmentService.publishAssessment(response.data._id, notificationMessage);
      } else {
        await assessmentService.publishAssessment(response.data._id);
      }

      // Clear any duplicate data from sessionStorage
      sessionStorage.removeItem('duplicateAssessmentData');
      toast.success("Assessment published successfully");
      navigate("/mentor/assessments");
    } catch (error) {
      console.error("Error publishing assessment:", error);
      toast.error("Failed to publish assessment");
    } finally {
      setLoading(false);
    }
  };

  const validateForm = () => {
    if (!formData.title || !formData.instructions || !formData.grade || !formData.sections || formData.sections.length === 0) {
      toast.error("Please fill in all required fields");
      return false;
    }

    // For SuperAdmin/LeadMentor, school is required
    if ((user?.role === "superadmin" || user?.role === "leadmentor") && !formData.school) {
      toast.error("Please select a school");
      return false;
    }

    if (selectedQuestions.length === 0) {
      toast.error("Please select at least one question");
      return false;
    }

    if (!formData.startDate || !formData.endDate) {
      toast.error("Please set start and end dates");
      return false;
    }

    const startDate = new Date(formData.startDate);
    const endDate = new Date(formData.endDate);
    const now = new Date();

    if (startDate <= now) {
      toast.error("Start date must be in the future");
      return false;
    }

    if (endDate <= startDate) {
      toast.error("End date must be after start date");
      return false;
    }

    return true;
  };

  const totalMarks = selectedQuestions.reduce((sum, q) => sum + q.marks, 0);

  return (
    <div className="container mx-auto p-4 sm:p-6 space-y-4 sm:space-y-6">
      <div className="space-y-4">
        <div>
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold">Create Assessment</h1>
          <p className="text-sm sm:text-base text-gray-600">Create a new assessment for your students</p>
        </div>
        <div className="flex flex-row gap-2 items-center justify-end">
          <Button variant="outline" onClick={() => navigate("/mentor/assessments")} className="w-max">  
            Cancel
          </Button>
          <Button variant="outline" onClick={handleSaveDraft} disabled={loading} className="w-max">
            <Save className="h-4 w-4 mr-2" />
            Save Draft
          </Button>
          <Button onClick={handlePublish} disabled={loading} className="w-max">
            <Send className="h-4 w-4 mr-2" />
            Publish
          </Button>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center space-x-2 sm:space-x-4 overflow-x-auto">
        {[1, 2, 3].map((stepNumber) => (
          <div key={stepNumber} className="flex items-center flex-shrink-0">
            <div className={`w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-xs sm:text-sm ${
              step >= stepNumber ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-600"
            }`}>
              {stepNumber}
            </div>
            <span className={`ml-1 sm:ml-2 text-xs sm:text-sm ${step >= stepNumber ? "text-blue-600" : "text-gray-600"}`}>
              {stepNumber === 1 ? "Basic Info" : stepNumber === 2 ? "Questions" : "Preview"}
            </span>
            {stepNumber < 3 && <div className="w-4 sm:w-8 h-px bg-gray-300 ml-2 sm:ml-4" />}
          </div>
        ))}
      </div>

      {/* Step 1: Basic Information */}
      {step === 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BookOpen className="h-5 w-5 mr-2" />
              Basic Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 sm:space-y-6">
            <div className="space-y-4 sm:space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Assessment Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => handleInputChange("title", e.target.value)}
                  placeholder="Enter assessment title"
                />
              </div>

              {/* School selection for all roles */}
              <div className="space-y-2">
                <Label htmlFor="school">School *</Label>
                <Select value={formData.school} onValueChange={(value) => handleInputChange("school", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select school" />
                  </SelectTrigger>
                  <SelectContent>
                    {schools.map(school => (
                      <SelectItem key={school._id} value={school._id}>{school.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Grade and Sections in single row for smaller screens */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="grade">Grade *</Label>
                  <Select value={formData.grade} onValueChange={(value) => handleInputChange("grade", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select grade" />
                    </SelectTrigger>
                    <SelectContent>
                      {hasServiceDetails ? (
                        availableGrades.map(gradeData => (
                          <SelectItem key={gradeData.grade} value={gradeData.grade.toString()}>{gradeData.grade}</SelectItem>
                        ))
                      ) : (
                        ["Grade 1", "Grade 2", "Grade 3", "Grade 4", "Grade 5", 
                         "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10"].map(grade => (
                          <SelectItem key={grade} value={grade}>{grade}</SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                  {hasServiceDetails && availableGrades.length === 0 && formData.school && (
                    <p className="text-xs sm:text-sm text-gray-500">No grades available for this school. Please configure service details first.</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sections">Sections *</Label>
                  <div className="space-y-1 sm:space-y-2">
                    {availableSections.map(section => (
                      <div key={section} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={`section-${section}`}
                          checked={formData.sections.includes(section)}
                          onChange={() => handleSectionToggle(section)}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <label htmlFor={`section-${section}`} className="text-xs sm:text-sm font-medium text-gray-700">
                          {section}
                        </label>
                      </div>
                    ))}
                  </div>
                  {hasServiceDetails && availableSections.length === 0 && formData.grade && (
                    <p className="text-xs sm:text-sm text-gray-500">No sections available for {formData.grade}. Please configure service details first.</p>
                  )}
                  {!hasServiceDetails && formData.school && (
                    <p className="text-xs sm:text-sm text-gray-500">Service details not configured for this school. Please contact administrator.</p>
                  )}
                  {formData.sections.length > 0 && (
                    <div className="mt-1">
                      <p className="text-xs sm:text-sm text-gray-600">Selected: {formData.sections.join(", ")}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Session selection removed as per new requirement */}
            </div>

            <div className="space-y-2">
              <Label htmlFor="instructions">Instructions *</Label>
              <Textarea
                id="instructions"
                value={formData.instructions}
                onChange={(e) => handleInputChange("instructions", e.target.value)}
                placeholder="Enter instructions for students"
                rows={3}
                className="text-sm"
              />
            </div>

            {/* Start and End dates in single row for smaller screens */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="startDate" className="text-sm">Start Date *</Label>
                <Input
                  id="startDate"
                  type="datetime-local"
                  value={formData.startDate}
                  onChange={(e) => handleInputChange("startDate", e.target.value)}
                  className="text-sm"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="endDate" className="text-sm">End Date *</Label>
                <Input
                  id="endDate"
                  type="datetime-local"
                  value={formData.endDate}
                  onChange={(e) => handleInputChange("endDate", e.target.value)}
                  className="text-sm"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="duration" className="text-sm">Duration (minutes) *</Label>
                <Input
                  id="duration"
                  type="number"
                  value={formData.duration}
                  onChange={(e) => handleInputChange("duration", parseInt(e.target.value))}
                  min="1"
                  className="text-sm"
                />
              </div>
            </div>

            <div className="flex justify-end">
              <Button 
                onClick={() => setStep(2)} 
                disabled={!formData.grade || formData.sections.length === 0 || !formData.school}
                className="w-full sm:w-auto text-sm"
              >
                Next: Select Questions
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Question Selection */}
      {step === 2 && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
          {/* Available Questions */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg sm:text-xl">Available Questions</CardTitle>
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search questions..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 text-sm"
                    />
                  </div>
                </div>
                <Select value={questionFilters.difficulty} onValueChange={(value) => 
                  setQuestionFilters(prev => ({ ...prev, difficulty: value }))
                }>
                  <SelectTrigger className="w-full sm:w-32 text-sm">
                    <SelectValue placeholder="Difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="Easy">Easy</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Tough">Tough</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-3 sm:p-6">
              <div className="space-y-2 sm:space-y-3 max-h-80 sm:max-h-96 overflow-y-auto">
                {filteredQuestions.map(question => (
                  <div key={question._id} className="border rounded-lg p-2 sm:p-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-1 sm:gap-2 mb-1 sm:mb-2">
                          <Checkbox
                            checked={selectedQuestions.some(q => q._id === question._id)}
                            onCheckedChange={() => handleQuestionSelect(question)}
                            className="h-4 w-4"
                          />
                          <Badge variant="outline" className="text-xs">{question.difficulty}</Badge>
                          <span className="text-xs sm:text-sm text-gray-500">{question.session?.displayName || question.session?.name}</span>
                        </div>
                        <p className="text-xs sm:text-sm">{question.questionText}</p>
                      </div>
                    </div>
                  </div>
                ))}
                {filteredQuestions.length === 0 && availableQuestions.length > 0 && (
                  <p className="text-center text-gray-500 py-4 text-sm">No questions match your search criteria</p>
                )}
                {availableQuestions.length === 0 && (
                  <p className="text-center text-gray-500 py-4 text-sm">No questions available</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Selected Questions */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg sm:text-xl">Selected Questions ({selectedQuestions.length})</CardTitle>
            </CardHeader>
            <CardContent className="p-3 sm:p-6">
              <div className="space-y-2 sm:space-y-3 max-h-80 sm:max-h-96 overflow-y-auto">
                {selectedQuestions.map((question) => (
                  <div key={question._id} className="border rounded-lg p-2 sm:p-3">
                    <div className="flex items-start justify-between mb-1 sm:mb-2">
                      <div className="flex items-center gap-1 sm:gap-2">
                        <span className="text-xs sm:text-sm font-medium">Q{question.order}</span>
                        <Badge variant="outline" className="text-xs">{question.difficulty}</Badge>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeQuestion(question._id)}
                        className="h-6 w-6 p-0"
                      >
                        <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                      </Button>
                    </div>
                    <p className="text-xs sm:text-sm mb-1 sm:mb-2">{question.questionText}</p>
                    <div className="flex items-center gap-1 sm:gap-2">
                      <Label htmlFor={`marks-${question._id}`} className="text-xs">Marks:</Label>
                      <Input
                        id={`marks-${question._id}`}
                        type="number"
                        value={question.marks}
                        onChange={(e) => handleQuestionMarksChange(question._id, parseInt(e.target.value))}
                        className="w-12 sm:w-16 h-6 sm:h-8 text-xs"
                        min="1"
                      />
                    </div>
                  </div>
                ))}
                {selectedQuestions.length === 0 && (
                  <p className="text-center text-gray-500 py-4 text-sm">No questions selected</p>
                )}
              </div>
              {selectedQuestions.length > 0 && (
                <div className="mt-3 sm:mt-4 p-2 sm:p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs sm:text-sm font-medium">Total Marks: {totalMarks}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step 3: Preview */}
      {step === 3 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-lg sm:text-xl">
              <Eye className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
              Assessment Preview
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 sm:space-y-6 p-3 sm:p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
              <div>
                <h3 className="font-semibold mb-2 text-sm sm:text-base">Basic Information</h3>
                <div className="space-y-1 sm:space-y-2 text-xs sm:text-sm">
                  <p><strong>Title:</strong> {formData.title}</p>
                  {(user?.role === "superadmin" || user?.role === "leadmentor") && (
                    <p><strong>School:</strong> {schools.find(s => s._id === formData.school)?.name || "Not selected"}</p>
                  )}
                  <p><strong>Grade:</strong> {formData.grade}</p>
                  <p><strong>Sections:</strong> {formData.sections.join(", ")}</p>
                  {/* Session removed from preview */}
                  <p><strong>Duration:</strong> {formData.duration} minutes</p>
                  <p><strong>Total Questions:</strong> {selectedQuestions.length}</p>
                  <p><strong>Total Marks:</strong> {totalMarks}</p>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-2 text-sm sm:text-base">Schedule</h3>
                <div className="space-y-1 sm:space-y-2 text-xs sm:text-sm">
                  <p><strong>Start Date:</strong> {new Date(formData.startDate).toLocaleString()}</p>
                  <p><strong>End Date:</strong> {new Date(formData.endDate).toLocaleString()}</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-sm sm:text-base">Instructions</h3>
              <p className="text-xs sm:text-sm bg-gray-50 p-2 sm:p-3 rounded-lg">{formData.instructions}</p>
            </div>

            <div>
              <h3 className="font-semibold mb-2 text-sm sm:text-base">Questions ({selectedQuestions.length})</h3>
              <div className="space-y-2 sm:space-y-3">
                {selectedQuestions.map((question, index) => (
                  <div key={question._id} className="border rounded-lg p-2 sm:p-3">
                    <div className="flex items-center justify-between mb-1 sm:mb-2">
                      <span className="font-medium text-xs sm:text-sm">Question {index + 1}</span>
                      <Badge variant="outline" className="text-xs">{question.marks} marks</Badge>
                    </div>
                    <p className="text-xs sm:text-sm">{question.questionText}</p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Navigation */}
      {step > 1 && (
        <div className="flex flex-col sm:flex-row justify-between gap-2 sm:gap-0">
          <Button variant="outline" onClick={() => setStep(step - 1)} className="w-full sm:w-auto text-sm">
            Previous
          </Button>
          {step < 3 && (
            <Button onClick={() => setStep(step + 1)} disabled={selectedQuestions.length === 0} className="w-full sm:w-auto text-sm">
              Next
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
