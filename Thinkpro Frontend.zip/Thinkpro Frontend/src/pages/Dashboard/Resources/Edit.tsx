import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { 
  ArrowLeft, 
  Upload, 
  Link, 
  FileText, 
  Video,
  X,
  Plus,
  Trash2,
  Loader2,
  Check,
  ChevronsUpDown
} from 'lucide-react';
import type { UserType } from '@/types/resources';
import type { Resource as ApiResource, UpdateResourceData } from '@/api/resourceService';
import { resourceService } from '@/api/resourceService';
import { sessionService, type Session } from '@/api/sessionService';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export default function EditResourcePage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const basePath = user?.role === 'superadmin' ? '/superadmin' : '/leadmentor';
  const goBack = () => {
    if (window.history.length > 2) {
      navigate(-1);
    } else {
      navigate(`${basePath}/resources`);
    }
  };
  
  const [formData, setFormData] = useState<UpdateResourceData>({
    title: '',
    description: '',
    type: 'document',
    category: 'student',
    url: '',
    tags: []
  });

  const [newTag, setNewTag] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [selectedSession, setSelectedSession] = useState<string>('');
  const [loadingSessions, setLoadingSessions] = useState(false);
  const [sessionSelectOpen, setSessionSelectOpen] = useState(false);
  const [contentMethod, setContentMethod] = useState<'file' | 'url'>('file');
  const [resource, setResource] = useState<ApiResource | null>(null);

  useEffect(() => {
    const loadData = async () => {
      if (!id) return;
      
      setIsLoading(true);
      try {
        // Load resource data
        const resourceResponse = await resourceService.getById(id);
        const resourceData = resourceResponse.data;
        setResource(resourceData);

        // Set form data from the resource
        setFormData({
          title: resourceData.title,
          description: resourceData.description,
          type: resourceData.type,
          category: resourceData.category,
          session: resourceData.session?._id,
          url: resourceData.content.url,
          tags: resourceData.tags,
          isPublic: resourceData.isPublic,
        });

        // Set session selection
        setSelectedSession(resourceData.session?._id || '');

        // Set content method based on whether the resource is external
        setContentMethod(resourceData.content.isExternal ? 'url' : 'file');
      } catch (error) {
        console.error('Error loading data:', error);
        toast.error('Failed to load resource data');
        goBack();
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [id, navigate]);

  // Load sessions when target audience is student or mentor
  useEffect(() => {
    const loadSessions = async () => {
      if (formData.category === 'student' || formData.category === 'mentor') {
        setLoadingSessions(true);
        try {
          const sessionsData = await sessionService.getAllSessions();
          setSessions(sessionsData);
        } catch (error) {
          console.error('Error loading sessions:', error);
          toast.error('Failed to load sessions');
        } finally {
          setLoadingSessions(false);
        }
      } else {
        setSessions([]);
        setSelectedSession('');
      }
    };

    loadSessions();
  }, [formData.category]);

  const handleInputChange = (field: keyof UpdateResourceData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAddTag = () => {
    if (newTag.trim() && !formData.tags?.includes(newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...(prev.tags || []), newTag.trim()]
      }));
      setNewTag('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags?.filter(tag => tag !== tagToRemove) || []
    }));
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFormData(prev => ({
        ...prev,
        file: file
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id) return;

    setIsUpdating(true);
    try {
      // Validate required fields
      if (!formData.title || !formData.type || !formData.category) {
        toast.error('Please fill in all required fields');
        return;
      }

      // Validate session selection for student/mentor resources
      if (formData.category === 'student' || formData.category === 'mentor') {
        if (!selectedSession) {
          toast.error('Please select a session for student/mentor resources');
          return;
        }
      }

      if (contentMethod === 'file' && !formData.file && !resource?.content.url) {
        toast.error('Please select a file to upload');
        return;
      }

      if (contentMethod === 'url' && !formData.url) {
        toast.error('Please provide an external URL');
        return;
      }

      // Prepare the resource data with session field
      const resourceData = {
        ...formData,
        session: selectedSession || undefined,
      };

      console.log('Resource data being updated:', resourceData);

      // Update the resource
      await resourceService.update(id, resourceData);

      toast.success('Resource updated successfully!');
      goBack();
    } catch (error) {
      console.error('Error updating resource:', error);
      toast.error('Failed to update resource. Please try again.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleDelete = async () => {
    if (!id) return;
    
    if (!confirm('Are you sure you want to delete this resource? This action cannot be undone.')) {
      return;
    }

    try {
      await resourceService.delete(id);
      toast.success('Resource deleted successfully!');
      goBack();
    } catch (error) {
      console.error('Error deleting resource:', error);
      toast.error('Failed to delete resource. Please try again.');
    }
  };

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Video className="h-5 w-5" />;
      case 'document':
      default:
        return <FileText className="h-5 w-5" />;
    }
  };

  const getAcceptedFileTypes = (type: string) => {
    switch (type) {
      case 'video':
        return 'video/mp4,video/avi,video/mov,video/wmv';
      case 'document':
      default:
        return '.pdf,.pptx,.xlsx,.docx,.doc,.xls,.ppt';
    }
  };

  const getFileTypeDescription = (type: string) => {
    switch (type) {
      case 'video':
        return 'Supported formats: MP4, AVI, MOV, WMV';
      case 'document':
      default:
        return 'Supported formats: PDF, PPTX, XLSX, DOCX, DOC, XLS, PPT';
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 max-w-4xl">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" />
          <span className="ml-2">Loading resource...</span>
        </div>
      </div>
    );
  }

  if (!resource) {
    return (
      <div className="container mx-auto p-6 max-w-4xl">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-2">Resource not found</h2>
          <p className="text-muted-foreground mb-4">
            The resource you're looking for doesn't exist or has been deleted.
          </p>
          <Button onClick={goBack}>
            Back to Resources
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="flex items-center gap-4 mb-6">
        <Button
          variant="outline"
          size="sm"
          onClick={goBack}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold">Edit Resource</h1>
          <p className="text-muted-foreground">
            Update the resource information and content
          </p>
        </div>
        <Button
          variant="destructive"
          onClick={handleDelete}
          className="flex items-center gap-2"
        >
          <Trash2 className="h-4 w-4" />
          Delete
        </Button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <Card>
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
            <CardDescription>
              Update basic details about the resource
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  placeholder="Enter resource title"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Target Audience *</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value: UserType) =>
                    handleInputChange('category', value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="student">Students</SelectItem>
                    <SelectItem value="mentor">Mentors</SelectItem>
                    <SelectItem value="guest">Guests</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) =>
                  handleInputChange('description', e.target.value)
                }
                placeholder="Describe the resource content and purpose"
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        {/* Session Selection - Only show for student/mentor resources */}
        {(formData.category === 'student' || formData.category === 'mentor') && (
          <Card>
            <CardHeader>
              <CardTitle>Session Association</CardTitle>
              <CardDescription>
                Link this resource to a specific session
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="session">Session *</Label>
                <Popover open={sessionSelectOpen} onOpenChange={setSessionSelectOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      role="combobox"
                      aria-expanded={sessionSelectOpen}
                      className="w-full justify-between"
                      disabled={loadingSessions}
                    >
                      {selectedSession
                        ? sessions.find((session) => session._id === selectedSession)
                          ? `${sessions.find((session) => session._id === selectedSession)?.grade}.${sessions.find((session) => session._id === selectedSession)?.sessionNumber?.toString().padStart(2, '0')} ${sessions.find((session) => session._id === selectedSession)?.name}`
                          : "Select session..."
                        : "Select session..."}
                      <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-full p-0">
                    <Command>
                      <CommandInput placeholder="Search sessions..." />
                      <CommandList>
                        <CommandEmpty>No sessions found.</CommandEmpty>
                        <CommandGroup>
                          {sessions.map((session) => (
                            <CommandItem
                              key={session._id}
                              value={`${session.grade}.${session.sessionNumber?.toString().padStart(2, '0')} ${session.name}`}
                              onSelect={() => {
                                setSelectedSession(session._id!);
                                setSessionSelectOpen(false);
                              }}
                            >
                              <Check
                                className={`mr-2 h-4 w-4 ${
                                  selectedSession === session._id ? "opacity-100" : "opacity-0"
                                }`}
                              />
                              <div className="flex flex-col">
                                <span className="font-medium">
                                  {session.grade}.{session.sessionNumber?.toString().padStart(2, '0')} {session.name}
                                </span>
                                {session.module && (
                                  <span className="text-sm text-gray-500">{typeof session.module === 'string' ? session.module : session.module.name}</span>
                                )}
                              </div>
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>
                {loadingSessions && (
                  <p className="text-sm text-muted-foreground">Loading sessions...</p>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Content Type and Method */}
        <Card>
          <CardHeader>
            <CardTitle>Content Details</CardTitle>
            <CardDescription>
              Choose the resource type and how you want to provide the content
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Resource Type Selection */}
            <div className="space-y-3">
              <Label>Resource Type *</Label>
              <RadioGroup
                value={formData.type}
                onValueChange={(value) => handleInputChange('type', value)}
                className="grid grid-cols-2 gap-4"
              >
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                  <RadioGroupItem value="document" id="document" />
                  <Label htmlFor="document" className="flex items-center gap-2 cursor-pointer">
                    <FileText className="h-4 w-4" />
                    Document
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                  <RadioGroupItem value="video" id="video" />
                  <Label htmlFor="video" className="flex items-center gap-2 cursor-pointer">
                    <Video className="h-4 w-4" />
                    Video
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Content Method Selection */}
            <div className="space-y-3">
              <Label>How would you like to provide the content?</Label>
              <RadioGroup
                value={contentMethod}
                onValueChange={(value) => setContentMethod(value as 'file' | 'url')}
                className="grid grid-cols-2 gap-4"
              >
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                  <RadioGroupItem value="file" id="file-method" />
                  <Label htmlFor="file-method" className="flex items-center gap-2 cursor-pointer">
                    <Upload className="h-4 w-4" />
                    Upload File
                  </Label>
                </div>
                <div className="flex items-center space-x-2 p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                  <RadioGroupItem value="url" id="url-method" />
                  <Label htmlFor="url-method" className="flex items-center gap-2 cursor-pointer">
                    <Link className="h-4 w-4" />
                    External URL
                  </Label>
                </div>
              </RadioGroup>
            </div>

            {/* Content Input Based on Method */}
            {contentMethod === 'file' ? (
              <div className="space-y-3">
                <Label htmlFor="file">Upload File</Label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-gray-400 transition-colors">
                  <Input
                    id="file"
                    type="file"
                    onChange={handleFileUpload}
                    accept={getAcceptedFileTypes(formData.type || '')}
                    className="hidden"
                  />
                  <Label htmlFor="file" className="cursor-pointer">
                    <div className="flex flex-col items-center gap-2">
                      {getFileIcon(formData.type || '')}
                      <span className="text-sm font-medium">Click to upload or drag and drop</span>
                      <span className="text-xs text-gray-500">
                        {getFileTypeDescription(formData.type || '')}
                      </span>
                    </div>
                  </Label>
                </div>
                {formData.file && (
                  <div className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                    {getFileIcon(formData.type || '')}
                    <span className="text-sm">{formData.file.name}</span>
                    <span className="text-xs text-gray-500">
                      ({(formData.file.size / 1024 / 1024).toFixed(2)} MB)
                    </span>
                  </div>
                )}
                {resource.content.fileName && !formData.file && (
                  <div className="flex items-center gap-2 p-2 bg-blue-50 rounded">
                    {getFileIcon(formData.type || '')}
                    <span className="text-sm text-blue-700">Current file: {resource.content.fileName}</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                <Label htmlFor="url">Resource URL</Label>
                <Input
                  id="url"
                  type="url"
                  value={formData.url}
                  onChange={(e) => handleInputChange('url', e.target.value)}
                  placeholder={
                    formData.type === 'video'
                      ? 'https://youtube.com/watch?v=... or https://vimeo.com/...'
                      : 'https://example.com/document.pdf'
                  }
                />
                <p className="text-sm text-gray-500">
                  {formData.type === 'video'
                    ? 'YouTube, Vimeo, or direct video links'
                    : 'Direct links to documents or external resources'}
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Tags */}
        <Card>
          <CardHeader>
            <CardTitle>Tags</CardTitle>
            <CardDescription>
              Add tags to help categorize and search for this resource
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="Enter a tag"
                onKeyPress={(e) =>
                  e.key === 'Enter' && (e.preventDefault(), handleAddTag())
                }
              />
              <Button type="button" onClick={handleAddTag} variant="outline">
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            {formData.tags && formData.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.tags.map((tag) => (
                  <Badge
                    key={tag}
                    variant="secondary"
                    className="flex items-center gap-1"
                  >
                    {tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="ml-1 hover:bg-destructive/20 rounded-full p-0.5"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-end gap-4">
          <Button
            type="button"
            variant="outline"
            onClick={goBack}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={isUpdating}>
            {isUpdating ? 'Updating...' : 'Update Resource'}
          </Button>
        </div>
      </form>
    </div>
  );
}